class CONST {
  static const String API_BASE_URL = 'https://ykapay.khanhlinh.pro';
  static const List ROLES_DEV = [
    'member_request',
  ]; // set null to disable bypass
  static const String DEFAULT_FORMAT_DATETIME = 'hh:mm dd/MM/yyyy';
}

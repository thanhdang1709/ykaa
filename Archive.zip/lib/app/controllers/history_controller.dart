import 'package:ykapay/utils/get_tool/get_tool.dart';
import 'package:get/get.dart';

class HistoryController extends GetxController with GetTool {
  // handle here
}

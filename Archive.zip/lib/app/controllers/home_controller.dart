import 'package:ykapay/utils/get_tool/get_tool.dart';
import 'package:get/get.dart';

class HomeController extends GetxController with GetTool {
  // handle here
}

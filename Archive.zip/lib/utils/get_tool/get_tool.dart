import 'dart:async';
import 'dart:ui';
import 'package:get/get.dart';

part 'future.dart';
part 'notify.dart';

class GetTool {
  NotifyModule notify = NotifyModule();
}
